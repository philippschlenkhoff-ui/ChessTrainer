//NOTE: We put these in another file because make greps through evaluate.h for these strings.
#define EvalFileDefaultNameBig "nn-9067e33176e8.nnue"
#define EvalFileDefaultNameSmall ""
